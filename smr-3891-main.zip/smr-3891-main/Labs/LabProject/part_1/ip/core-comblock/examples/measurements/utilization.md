|Instance|Module|TotalLUTs|LogicLUTs|LUTRAMs|SRLs|FFs|RAMB36|RAMB18|DSP48Blocks|
|-|-|-|-|-|-|-|-|-|-|
|comblock_full|design_1_comblock_full_0|648|648|0|0|784|32|2|0|
|comblock_fifos|design_1_comblock_fifos_0|224|224|0|0|187|0|2|0|
|comblock_dram|design_1_comblock_dram_0|128|128|0|0|76|32|0|0|
|comblock_regs16|design_1_comblock_regs16_0|305|305|0|0|564|0|0|0|
|comblock_regs4|design_1_comblock_regs4_0|107|107|0|0|178|0|0|0|
