

#ifndef FIRTOP_H_
#define FIRTOP_H_
#define N	181

typedef int	coef_t;
typedef int	data_t;
typedef int	acc_t;

void fir (
  data_t *y,
  //coef_t c[N+1],
  data_t x
  );

#endif
